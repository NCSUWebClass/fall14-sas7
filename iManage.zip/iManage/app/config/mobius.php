<?php

return array(
	'install' => false,
	'version' => '',	
	'installationDate' => '',
	'installationHost' => null,
);
