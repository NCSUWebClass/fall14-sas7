<?php

class Todos extends Eloquent{

	protected $table = 'todos';
}