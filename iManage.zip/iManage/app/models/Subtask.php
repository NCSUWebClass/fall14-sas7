<?php 
 /* Eloquent class for subtasks table */
class Subtask extends \Eloquent {
 
    protected $table = 'subtasks';
 
    protected $softDelete = true;

    
    
	
 
}